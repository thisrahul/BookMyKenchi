package com.thisrahul.bookmykenchi.ui.home;

public interface HomeListener {

    void onClick();
}
